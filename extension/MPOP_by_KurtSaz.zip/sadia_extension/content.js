// content.js — Deep project data extractor for Freelancer.com

function extractProjectData() {
  const data = {
    title: "",
    description: "",
    skills: [],
    budget: "",
    url: window.location.href
  };

  // ── TITLE ──
  const titleSelectors = [
    "h1.PageProjectViewLogout-header-title",
    ".PageProjectViewLogout-header h1",
    "h1[itemprop='title']",
    ".project-title h1",
    "h1.title",
    "h1"
  ];
  for (const s of titleSelectors) {
    const el = document.querySelector(s);
    if (el && el.innerText.trim()) { data.title = el.innerText.trim(); break; }
  }

  // ── DESCRIPTION — try every known Freelancer selector aggressively ──
  const descSelectors = [
    // Logged-out project view
    ".PageProjectViewLogout-detail-description",
    // Logged-in project view
    ".PageProjectViewLoggedIn-detail-description",
    // Generic project description containers
    "[class*='project-description']",
    "[class*='ProjectDescription']",
    "[class*='description-text']",
    "[class*='project-detail']",
    "[data-cy='project-description']",
    // itemprop
    "[itemprop='description']",
    // Common class names used by Freelancer
    ".NativeElement",
    ".project-details-section",
    ".project-body",
    ".project-text",
    // Broad fallbacks
    "app-project-description",
    "[class*='Description']"
  ];

  for (const s of descSelectors) {
    const el = document.querySelector(s);
    if (el) {
      const text = el.innerText.trim();
      if (text.length > 50) {
        data.description = text;
        break;
      }
    }
  }

  // ── FALLBACK: grab ALL visible text blocks on the page ──
  // Freelancer uses Angular/React so sometimes text is in divs not p tags
  if (!data.description || data.description.length < 50) {
    const candidates = [];

    // Try all divs and paragraphs with meaningful content
    const allEls = document.querySelectorAll("p, div, li, span");
    for (const el of allEls) {
      // Skip hidden elements, nav, header, footer, scripts
      const tag = el.tagName.toLowerCase();
      const classes = el.className.toLowerCase();
      if (
        classes.includes("nav") || classes.includes("footer") ||
        classes.includes("header") || classes.includes("menu") ||
        classes.includes("sidebar") || classes.includes("bid") ||
        classes.includes("button") || classes.includes("btn") ||
        el.offsetParent === null
      ) continue;

      // Only direct text (not children)
      const ownText = Array.from(el.childNodes)
        .filter(n => n.nodeType === Node.TEXT_NODE)
        .map(n => n.textContent.trim())
        .join(" ")
        .trim();

      if (ownText.length > 40) candidates.push(ownText);
    }

    if (candidates.length > 0) {
      // Deduplicate and join
      const unique = [...new Set(candidates)];
      data.description = unique.slice(0, 30).join("\n");
    }
  }

  // ── SKILLS ──
  const skillSelectors = [
    ".PageProjectViewLogout-skills a",
    ".PageProjectViewLoggedIn-skills a",
    "[class*='skills'] a",
    "[class*='Skills'] a",
    ".tag-list a",
    "[class*='tag'] a",
    "[data-cy='skill'] a",
    "app-project-skills a"
  ];
  for (const s of skillSelectors) {
    const els = document.querySelectorAll(s);
    if (els.length > 0) {
      data.skills = Array.from(els).map(e => e.innerText.trim()).filter(Boolean);
      break;
    }
  }

  // ── BUDGET ──
  const budgetSelectors = [
    ".PageProjectViewLogout-header-budget",
    ".PageProjectViewLoggedIn-header-budget",
    "[class*='budget']",
    "[class*='Budget']",
    "[data-cy='budget']"
  ];
  for (const s of budgetSelectors) {
    const el = document.querySelector(s);
    if (el && el.innerText.trim()) {
      data.budget = el.innerText.trim().replace(/\s+/g, " ");
      break;
    }
  }

  // Clean up description — remove excessive whitespace
  if (data.description) {
    data.description = data.description
      .replace(/\t/g, " ")
      .replace(/[ ]{3,}/g, " ")
      .replace(/\n{4,}/g, "\n\n")
      .trim();
  }

  return data;
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "getProjectData") {
    sendResponse(extractProjectData());
  }
  return true;
});
