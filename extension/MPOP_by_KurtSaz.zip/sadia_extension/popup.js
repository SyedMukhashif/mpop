// MPOP by KurtSaz — popup.js v5 (stress-tested, full features)

// ── SADIA'S PROFILE ──
const SADIA_PROFILE = `
Name: Sadia Babur | Rating: 4.8/5 (48 reviews) | 94% on-time | 100% on-budget
Rate: $12/hr | Based in Pakistan | Freelancer since May 2024

SKILLS:
- Web: WordPress, Shopify, Webflow, Wix, Elementor, Divi, WooCommerce
- Frontend: HTML, CSS, JavaScript, React, Tailwind CSS
- Backend: PHP, Laravel, MySQL, Node.js
- UI/UX: Figma, Adobe XD — wireframes, prototypes, mobile-first design
- Graphic Design: Logo & brand identity, flyers, brochures, social media, packaging
- Tools: Adobe Photoshop, Illustrator, Figma, Canva
- Marketing: Google Ads, campaign setup, keyword research, A/B testing

STRENGTHS: Delivers EXACTLY what client needs, unlimited revisions, fast communication, always on-time & on-budget.
PAST WORK: AI Investment Forum (FastAPI+Django+ML), company profiles, celebrity event flyers, websites for entertainment/health/sports brands, full WordPress/Shopify/Webflow builds.
`;

// ── STATE ──
let projectData   = null;
let selectedTone  = "professional";
let selectedLen   = "medium";
let isGenerating  = false;
let proposalHistory = [];   // stores up to 3 proposals
let activeHistory   = 0;    // which history tab is active

// ── DOM REFS ──
const statusBar        = document.getElementById("statusBar");
const statusText       = document.getElementById("statusText");
const projectPreview   = document.getElementById("projectPreview");
const previewTitle     = document.getElementById("previewTitle");
const previewMeta      = document.getElementById("previewMeta");
const notOnProject     = document.getElementById("notOnProject");
const controlsSection  = document.getElementById("controlsSection");
const generateBtn      = document.getElementById("generateBtn");
const spinner          = document.getElementById("spinner");
const btnText          = document.getElementById("btnText");
const proposalSection  = document.getElementById("proposalSection");
const historySection   = document.getElementById("historySection");
const historyTabs      = document.getElementById("historyTabs");
const proposalText     = document.getElementById("proposalText");
const wordCount        = document.getElementById("wordCount");
const charCount        = document.getElementById("charCount");
const copyBtn          = document.getElementById("copyBtn");
const regenBtn         = document.getElementById("regenBtn");
const apiNotice        = document.getElementById("apiNotice");
const settingsToggle   = document.getElementById("settingsToggle");
const settingsPanel    = document.getElementById("settingsPanel");
const apiKeyInput      = document.getElementById("apiKeyInput");
const apiKeyHint       = document.getElementById("apiKeyHint");
const nameInput        = document.getElementById("nameInput");
const customNoteInput  = document.getElementById("customNote");
const saveSettingsBtn  = document.getElementById("saveSettings");
const savedMsg         = document.getElementById("savedMsg");
const openSettingsLink = document.getElementById("openSettingsLink");
const todayCounter     = document.getElementById("todayCounter");

// ── INIT ──
document.addEventListener("DOMContentLoaded", async () => {
  await loadSettings();
  await loadTodayCount();
  await detectProjectPage();
});

// ── SETTINGS ──
async function loadSettings() {
  const data = await chrome.storage.local.get(["apiKey", "userName", "customNote"]);
  if (data.apiKey)     apiKeyInput.value     = data.apiKey;
  if (data.userName)   nameInput.value       = data.userName;
  if (data.customNote) customNoteInput.value = data.customNote;
  if (!data.apiKey)    apiNotice.style.display = "block";
}

settingsToggle.addEventListener("click", () => {
  const isOpen = settingsPanel.style.display === "block";
  settingsPanel.style.display = isOpen ? "none" : "block";
  settingsToggle.textContent  = isOpen ? "Settings" : "Close";
});

openSettingsLink.addEventListener("click", (e) => {
  e.preventDefault();
  settingsPanel.style.display = "block";
  settingsToggle.textContent  = "Close";
  apiKeyInput.focus();
});

// API key validation hint
apiKeyInput.addEventListener("input", () => {
  const val = apiKeyInput.value.trim();
  if (!val) {
    apiKeyHint.textContent = "Get free key at console.groq.com";
    apiKeyHint.className = "hint";
  } else if (!val.startsWith("gsk_")) {
    apiKeyHint.textContent = "Warning: Groq keys start with gsk_";
    apiKeyHint.className = "hint warn";
  } else {
    apiKeyHint.textContent = "Key looks valid";
    apiKeyHint.className = "hint";
    apiKeyHint.style.color = "#4ade80";
  }
});

saveSettingsBtn.addEventListener("click", async () => {
  const key = apiKeyInput.value.trim();
  if (key && !key.startsWith("gsk_")) {
    apiKeyHint.textContent = "Invalid key format — Groq keys start with gsk_";
    apiKeyHint.className = "hint warn";
    return;
  }
  await chrome.storage.local.set({
    apiKey:     key,
    userName:   nameInput.value.trim(),
    customNote: customNoteInput.value.trim()
  });
  apiNotice.style.display = key ? "none" : "block";
  savedMsg.style.display  = "block";
  setTimeout(() => { savedMsg.style.display = "none"; }, 2000);
});

// ── DAILY COUNTER ──
async function loadTodayCount() {
  const today = new Date().toDateString();
  const data  = await chrome.storage.local.get(["countDate", "countNum"]);
  if (data.countDate !== today) {
    await chrome.storage.local.set({ countDate: today, countNum: 0 });
    updateCounter(0);
  } else {
    updateCounter(data.countNum || 0);
  }
}

function updateCounter(n) {
  todayCounter.textContent = n + " today";
  todayCounter.className   = n > 0 ? "stat-pill active" : "stat-pill";
}

async function incrementCounter() {
  const today = new Date().toDateString();
  const data  = await chrome.storage.local.get(["countDate", "countNum"]);
  const n     = (data.countDate === today ? (data.countNum || 0) : 0) + 1;
  await chrome.storage.local.set({ countDate: today, countNum: n });
  updateCounter(n);
}

// ── PAGE DETECTION ──
async function detectProjectPage() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.url) return;

  if (!tab.url.includes("freelancer.com/projects/")) {
    notOnProject.style.display    = "block";
    controlsSection.style.display = "none";
    setStatus("normal", "Open a Freelancer.com project page.");
    return;
  }

  try {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
    chrome.tabs.sendMessage(tab.id, { action: "getProjectData" }, (response) => {
      if (chrome.runtime.lastError || !response) {
        setStatus("error", "Could not read page — try refreshing the tab.");
        return;
      }
      projectData = response;
      showProjectPreview(projectData);
      setStatus("detected", "Project detected — ready to write!");
      controlsSection.style.display = "block";
    });
  } catch (e) {
    setStatus("error", "Cannot access this page. Try refreshing.");
  }
}

function showProjectPreview(data) {
  projectPreview.style.display = "block";
  previewTitle.textContent = data.title || "Untitled Project";
  previewMeta.innerHTML = "";

  if (data.budget) {
    addBadge(previewMeta, data.budget, "budget");
  }
  (data.skills || []).slice(0, 4).forEach(skill => addBadge(previewMeta, skill, ""));

  if (data.description) {
    const chars = data.description.length;
    const cls   = chars < 100 ? "warn-badge" : "desc-badge";
    const label = chars < 100 ? "Short desc — " + chars + " chars" : chars + " chars read";
    addBadge(previewMeta, label, cls);
  }
}

function addBadge(container, text, cls) {
  const el = document.createElement("span");
  el.className = "badge " + cls;
  el.textContent = text;
  container.appendChild(el);
}

function setStatus(type, message) {
  statusBar.className = type === "detected" ? "detected" : type === "error" ? "error" : "";
  statusText.textContent = message;
}

// ── TONE & LENGTH BUTTONS ──
document.querySelectorAll(".tone-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tone-btn").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    selectedTone = btn.dataset.tone;
  });
});
document.querySelectorAll(".len-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".len-btn").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    selectedLen = btn.dataset.len;
  });
});

// ── GENERATE ──
generateBtn.addEventListener("click", generateProposal);
regenBtn.addEventListener("click", generateProposal);

async function generateProposal() {
  if (isGenerating) return;

  const stored = await chrome.storage.local.get(["apiKey", "userName", "customNote"]);
  if (!stored.apiKey) {
    settingsPanel.style.display = "block";
    settingsToggle.textContent  = "Close";
    apiKeyInput.focus();
    return;
  }
  if (!projectData || !projectData.title) {
    setStatus("error", "No project data. Please refresh the Freelancer page.");
    return;
  }

  isGenerating = true;
  spinner.style.display = "block";
  btnText.textContent   = "Writing...";
  generateBtn.disabled  = true;

  const toneGuide = {
    professional: "professional and polished",
    friendly:     "warm, friendly and approachable",
    confident:    "bold, confident and assertive",
    concise:      "direct and concise — no fluff"
  }[selectedTone];

  const userName   = stored.userName  || "Sadia Babur";
  const customNote = stored.customNote || "";
  const desc       = (projectData.description || "").slice(0, 2000);

  const structureGuide = {
    short: `Write EXACTLY 2 paragraphs. Total under 90 words. No more.

PARAGRAPH 1: One punchy sentence showing you read their specific project + one sentence on how you will deliver it.
PARAGRAPH 2: Include portfolio link "Portfolio: https://www.freelancer.com/u/SadiaBabur1" and a short call to action.`,

    medium: `Write EXACTLY 3 paragraphs. Total 120-150 words. No more, no less.

PARAGRAPH 1: Show you understood the project. Reference specific details from their description.
PARAGRAPH 2: Explain exactly how you will deliver it using your specific relevant skills and tools.
PARAGRAPH 3: Include "Portfolio: https://www.freelancer.com/u/SadiaBabur1" and a warm call to action.`,

    long: `Write EXACTLY 4 paragraphs. Total 180-210 words. No more, no less.

PARAGRAPH 1: Show deep understanding. Reference 2-3 specific things from their description.
PARAGRAPH 2: Explain exactly HOW you will solve their problem with specific skills/tools.
PARAGRAPH 3: Mention a relevant past project or experience that matches their needs.
PARAGRAPH 4: Include "Portfolio: https://www.freelancer.com/u/SadiaBabur1" and energetic call to action.`
  }[selectedLen];

  const prompt = `You are ${userName}, a top-rated freelancer on Freelancer.com writing a bid proposal.

PROJECT TITLE: ${projectData.title}
BUDGET: ${projectData.budget || "Not specified"}
SKILLS REQUIRED: ${(projectData.skills || []).join(", ") || "Not listed"}

PROJECT DESCRIPTION:
${desc || "Not available"}

YOUR PROFILE:
${SADIA_PROFILE}

TONE: ${toneGuide}

${structureGuide}

RULES:
- NEVER start with "Dear Client", "Hello", "Hi there"
- Open with energy — show you understood their SPECIFIC project
- Use 1-2 relevant emojis naturally in text (not at start of every line)
- ONE blank line between paragraphs
- NO bullet points or dashes in the proposal
- NEVER mention architecture, AutoCAD, SketchUp, Lumion, Revit, 3D modeling
${customNote ? `- End with: "${customNote}"` : ""}

Output ONLY the proposal text. No labels, no markdown, no extra intro.`;

  // 30 second timeout
  const controller = new AbortController();
  const timeout    = setTimeout(() => controller.abort(), 30000);

  try {
    const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method:  "POST",
      signal:  controller.signal,
      headers: {
        "Content-Type":  "application/json",
        "Authorization": `Bearer ${stored.apiKey}`
      },
      body: JSON.stringify({
        model:       "llama-3.3-70b-versatile",
        max_tokens:  800,
        temperature: 0.82,
        messages:    [{ role: "user", content: prompt }]
      })
    });
    clearTimeout(timeout);

    const data = await response.json();

    if (data.error) {
      // Better error messages
      const msg = data.error.message || "";
      if (msg.includes("auth") || msg.includes("key") || msg.includes("401")) {
        setStatus("error", "Invalid API key. Check Settings.");
      } else if (msg.includes("rate") || msg.includes("quota") || msg.includes("429")) {
        setStatus("error", "Rate limit hit. Wait 60 seconds and retry.");
      } else {
        setStatus("error", "API error: " + msg.slice(0, 60));
      }
    } else if (!data.choices || !data.choices[0]) {
      setStatus("error", "Unexpected response from API. Try again.");
    } else {
      let proposal = data.choices[0].message.content.trim();

      // Normalize line breaks — single blank line between paragraphs
      proposal = proposal
        .replace(/\r\n/g, "\n")
        .replace(/\n{3,}/g, "\n\n")
        .replace(/([^\n])\n([^\n])/g, "$1\n\n$2")
        .trim();

      // Save to history (max 3)
      proposalHistory.unshift(proposal);
      if (proposalHistory.length > 3) proposalHistory.pop();
      activeHistory = 0;

      displayProposal(proposal);
      renderHistoryTabs();
      await incrementCounter();
      setStatus("detected", "Project detected — ready to write!");
    }
  } catch (err) {
    clearTimeout(timeout);
    if (err.name === "AbortError") {
      setStatus("error", "Request timed out (30s). Check your connection.");
    } else {
      setStatus("error", "Network error. Check your internet connection.");
    }
    console.error(err);
  }

  isGenerating = false;
  spinner.style.display = "none";
  btnText.textContent   = "Generate Proposal";
  generateBtn.disabled  = false;
}

// ── DISPLAY PROPOSAL ──
function displayProposal(text) {
  proposalText.value            = text;
  proposalSection.style.display = "block";
  copyBtn.textContent           = "Copy Proposal";
  copyBtn.classList.remove("copied");
  updateCounts(text);
}

function updateCounts(text) {
  const words = text.trim().split(/\s+/).filter(Boolean).length;
  const chars = text.length;
  wordCount.textContent = words + " words";
  charCount.textContent = chars + " chars";
  // Freelancer minimum is 100 chars
  if (chars < 100) {
    charCount.className = "warn";
    charCount.title     = "Warning: Freelancer requires minimum 100 characters!";
  } else {
    charCount.className = "ok";
    charCount.title     = "Minimum character count met";
  }
}

// ── HISTORY TABS ──
function renderHistoryTabs() {
  if (proposalHistory.length <= 1) {
    historySection.style.display = "none";
    return;
  }
  historySection.style.display = "block";
  historyTabs.innerHTML = "";
  proposalHistory.forEach((_, i) => {
    const tab = document.createElement("button");
    tab.className   = "hist-tab" + (i === activeHistory ? " active" : "");
    tab.textContent = i === 0 ? "Latest" : i === 1 ? "Previous" : "Older";
    tab.addEventListener("click", () => {
      activeHistory = i;
      displayProposal(proposalHistory[i]);
      renderHistoryTabs();
    });
    historyTabs.appendChild(tab);
  });
}

// ── COPY ──
copyBtn.addEventListener("click", async () => {
  const text = proposalText.value;
  if (!text) return;
  try {
    await navigator.clipboard.writeText(text);
    copyBtn.textContent = "Copied!";
    copyBtn.classList.add("copied");
    setTimeout(() => {
      copyBtn.textContent = "Copy Proposal";
      copyBtn.classList.remove("copied");
    }, 2500);
  } catch (e) {
    // Fallback for clipboard permission
    proposalText.select();
    document.execCommand("copy");
    copyBtn.textContent = "Copied!";
    setTimeout(() => { copyBtn.textContent = "Copy Proposal"; }, 2500);
  }
});

// Update counts on manual edit
proposalText.addEventListener("input", () => {
  updateCounts(proposalText.value);
});
